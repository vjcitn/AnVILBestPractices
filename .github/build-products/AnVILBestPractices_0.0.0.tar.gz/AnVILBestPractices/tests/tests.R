library(AnVILBestPractices)
library(testthat)

test_check("AnVILBestPractices")
