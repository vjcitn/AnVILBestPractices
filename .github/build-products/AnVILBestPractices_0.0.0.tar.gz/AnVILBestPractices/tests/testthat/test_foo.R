
test_that("foo computes, etc.", {
 expect_true(foo() == 1)
})

